import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import ParallaxScene from "./components/ParallaxScene";
import About from "./components/About.jsx";
import ParallaxCursor from "./components/ParallaxCursor";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";


// Register ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

function App() {
  const mainRef = useRef(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    if (mainRef.current) {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: mainRef.current,
          start: "top top",
          end: "bottom bottom",
          scrub: 0.5,
        },
      });

      tl.to(mainRef.current, {
        scale: 1.15,
        y: -100,
        ease: "power1.out",
      });
    }

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    };
  }, []);

  return (
    <>
      {/* Pass setIsSidebarOpen to Navbar */}
      <Navbar setIsSidebarOpen={() => setIsSidebarOpen((prev) => !prev)} />

      {/* Sidebar */}
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      <div className="h-[200vh]">
        <div
          ref={mainRef}
          className="fixed top-0 left-0 w-full h-screen overflow-hidden"
        >
          <ParallaxScene />
        </div>
      </div>

      <ParallaxCursor />
    </>
  );
}

export default App;
